import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight } from "react-bootstrap-icons";

import { ROUTES_SEARCH_PAGE } from "../../routes/routes";

import ButtonComponent from "../../components/buttons/buttonComponent";
import HeaderComponent from "../../components/header/headerComponent";

const HomePage = () => {
  let navigate = useNavigate();
  return (
    <div>
      <HeaderComponent />
      <h1 className="fs-1 text-center"> HomePage</h1>
      <ButtonComponent
        variant="warning"
        className="mt-5"
        handleClick={() => {
          navigate(`${ROUTES_SEARCH_PAGE}`);
        }}
      >
        go to search page
        <ArrowRight color="black" size={20} className="mx-2"/>
      </ButtonComponent>
    </div>
  );
};

export default HomePage;
