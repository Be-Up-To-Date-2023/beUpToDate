export const ROUTES_HOME_PAGE = "/";
export const ROUTES_SEARCH_PAGE = "/search";
